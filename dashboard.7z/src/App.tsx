// import React Router Dom
import { Routes, Route } from "react-router-dom";

// Import components
import Login from "./pages/auth/login";
import NotFound from "./pages/notFound";
import ForgotPassword from "./pages/auth/forgotPassword";
import Dashboard from "./pages/dashboard";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/forgotPassword" element={<ForgotPassword />} />
      <Route path="*" element={<NotFound />} />
      {/* <Route index element={<Home />} /> */}
    </Routes>
  );
}

export default App;
