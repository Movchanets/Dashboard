import * as UserActionCreators from "./UserActions";

export default {
  ...UserActionCreators,
};
