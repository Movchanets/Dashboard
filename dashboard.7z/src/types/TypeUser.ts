export interface IUserType{
    email: string;
    password: string;
    rememberMe: boolean;
}